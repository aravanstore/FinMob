// ─────────────────────────────────────────────────────────────────────────────
// Изменения в main.dart
// ─────────────────────────────────────────────────────────────────────────────

// 1. Добавь импорты в начало main.dart:
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart'; // генерируется командой flutterfire configure
import 'services/push_notification_service.dart';

// 2. Замени void main() на async и добавь инициализацию:
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Инициализация Firebase
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const MyApp());
}

// 3. В MyApp или в экране после логина вызови:
// PushNotificationService.init(apiService);

// 4. В экране логина после успешного входа добавь:
// await PushNotificationService.registerToken(apiService);

// 5. При логауте добавь:
// await PushNotificationService.unregisterToken(apiService);
