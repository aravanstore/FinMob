// ─────────────────────────────────────────────────────────────────────────────
// Добавь эти методы в свой существующий api_service.dart
// ─────────────────────────────────────────────────────────────────────────────

// Сохранить FCM токен на сервере
Future<void> saveFcmToken(String token) async {
  await _dio.post(
    '/api/notifications/token',
    data: {
      'fcm_token': token,
      'device_info': Platform.operatingSystem, // 'android' или 'ios'
    },
  );
}

// Удалить FCM токен (при логауте)
Future<void> deleteFcmToken(String token) async {
  await _dio.delete(
    '/api/notifications/token',
    data: {'fcm_token': token},
  );
}
