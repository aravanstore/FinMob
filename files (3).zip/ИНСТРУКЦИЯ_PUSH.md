# Push-уведомления для FinMob — Полная инструкция

## Шаг 1 — Создать Firebase проект (10 минут, один раз)

1. Открой https://console.firebase.google.com
2. Нажми "Создать проект" → имя: `FinMob` → далее
3. Google Analytics — можно отключить → создать проект
4. В левом меню нажми шестерёнку ⚙️ → "Настройки проекта"
5. Вкладка "Ваши приложения" → нажми иконку Android
6. Имя пакета Android — найди в `android/app/build.gradle` строку `applicationId`
   Обычно что-то вроде: `com.meridian.finmob`
7. Скачай `google-services.json`
8. Положи файл в папку: `mobile/android/app/google-services.json`

---

## Шаг 2 — Скачать ключ для бэкенда (2 минуты)

1. В Firebase Console → ⚙️ → "Настройки проекта"
2. Вкладка "Сервисные аккаунты"
3. Нажми "Создать закрытый ключ" → скачается JSON файл
4. Переименуй файл в `serviceAccountKey.json`
5. Положи в папку: `backend/serviceAccountKey.json`

⚠️ ВАЖНО: добавь в backend/.gitignore:
```
serviceAccountKey.json
```

---

## Шаг 3 — Настроить Flutter (5 минут)

### Установи FlutterFire CLI:
```bash
dart pub global activate flutterfire_cli
```

### Добавь пакеты в pubspec.yaml:
```yaml
dependencies:
  firebase_core: ^3.6.0
  firebase_messaging: ^15.1.3
  flutter_local_notifications: ^17.2.2
```

### Запусти автонастройку:
```bash
cd mobile
flutterfire configure --project=finmob-XXXXX
```
(XXXXX — ID твоего Firebase проекта, видно в консоли)

Эта команда сама создаст файл `lib/firebase_options.dart`

### В android/build.gradle (верхний уровень) добавь:
```gradle
dependencies {
  classpath 'com.google.gms:google-services:4.4.0'
}
```

### В android/app/build.gradle в самый низ добавь:
```gradle
apply plugin: 'com.google.gms.google-services'
```

---

## Шаг 4 — Подключить файлы на бэкенд (2 минуты)

### Установи firebase-admin:
```bash
cd backend
npm install firebase-admin
```

### В index.js добавь ДВЕ строки:
```javascript
// После всех require в начале файла:
require('./push_scheduler'); // запускает cron каждый день в 09:00

// После других app.use роутов:
app.use('/api/notifications', require('./routes/notifications'));
```

### Скопируй файлы:
```
push_notifications/backend/notifications.js  →  backend/routes/notifications.js
push_notifications/backend/push_scheduler.js →  backend/push_scheduler.js
```

---

## Шаг 5 — Добавить код в Flutter (5 минут)

### Скопируй файлы:
```
push_notification_service.dart  →  mobile/lib/services/push_notification_service.dart
```

### Изменения в main.dart — смотри файл main_additions.dart

### В api_service.dart добавь два метода из api_service_additions.dart

---

## Шаг 6 — Проверить что работает

### Запусти бэкенд и проверь в логах:
```
[FCM] Firebase Admin SDK инициализирован
[FCM Scheduler] Следующий запуск: ...
```

### Тестовая отправка (замени TOKEN на реальный FCM токен из логов Flutter):
```bash
curl -X POST http://localhost:3002/api/notifications/test-send \
  -H "Content-Type: application/json" \
  -d '{"token": "ВАШ_FCM_ТОКЕН"}'
```

### FCM токен увидишь в логах Flutter когда откроешь приложение:
```
[FCM] Токен получен: dkj3h4k2j3h4...
```

---

## Что делают уведомления

| Когда | Заголовок | Текст |
|-------|-----------|-------|
| За 3 дня | 📅 Напоминание о платеже | Через 3 дня платёж по договору ... |
| За 1 день | ⏰ Платёж завтра | По договору ... — 5 000 сом |
| В день платежа | 💳 Платёж сегодня! | По договору ... Оплатите до конца дня |

---

## Если next_payment_date нет в таблице loans

Скажи мне — добавлю запрос который считает дату следующего платежа
автоматически по дате выдачи и сроку займа.
